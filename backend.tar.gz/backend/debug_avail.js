const axios = require('axios');
const https = require('https');

const httpsAgent = new https.Agent({ family: 4 });

async function test() {
    const url = "https://railjournal.in/RailRadar/Train/fetch_availability.php?trainNo=12313&src=SDAH&dst=NDLS&classes=2A&date=19-12-2025";
    console.log("Fetching:", url);
    try {
        const resp = await axios.get(url, {
            timeout: 20000,
            httpsAgent,
            headers: {
                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36'
            }
        });
        console.log("Status:", resp.status);
        console.log("Data:", JSON.stringify(resp.data, null, 2));
    } catch (e) {
        console.error("Error:", e.message);
        if (e.response) {
            console.error("Response Status:", e.response.status);
            console.error("Response Data:", e.response.data);
        }
    }
}

test();
