const mongoose = require('mongoose');
const Station = require('./models/Station');
require('dotenv').config();

async function testSearch(query) {
    try {
        await mongoose.connect(process.env.MONGO_URI);
        const regex = new RegExp(query, 'i');
        const stations = await Station.find({
            $or: [{ code: regex }, { name: regex }]
        }).limit(5);

        console.log(`Query: "${query}"`);
        console.log(stations);
    } catch (e) {
        console.error(e);
    } finally {
        await mongoose.disconnect();
    }
}

testSearch("how");
