const axios = require('axios');

async function test() {
    const baseUrl = "http://localhost:4000/api";
    try {
        // 1. Login
        console.log("Logging in...");
        const loginResp = await axios.post("http://localhost:4000/api/login", {
            username: "admin",
            password: "Mypassword4321*"
        });
        const token = loginResp.data.token;
        console.log("Got token:", token ? "YES" : "NO");

        // 2. Call Seat Availability
        const url = `${baseUrl}/seat-availability?trainNo=12313&src=SDAH&dst=NDLS&classes=2A&date=19-12-2025`;
        console.log("Fetching:", url);
        const resp = await axios.get(url, {
            headers: { Authorization: `Bearer ${token}` }
        });

        console.log("Status:", resp.status);
        console.log("Data:", JSON.stringify(resp.data, null, 2));

    } catch (e) {
        console.error("Error:", e.message);
        if (e.response) {
            console.error("Response Status:", e.response.status);
            console.error("Response Data:", e.response.data);
        }
    }
}

test();
