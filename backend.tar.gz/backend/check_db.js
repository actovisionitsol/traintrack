const mongoose = require('mongoose');
require('dotenv').config();

const uri = process.env.MONGO_URI;

async function check() {
    try {
        console.log("Connecting to:", uri);
        await mongoose.connect(uri);
        console.log("Connected!");

        const collections = await mongoose.connection.db.listCollections().toArray();
        console.log("Collections:", collections.map(c => c.name));

        for (const col of collections) {
            console.log(`\n--- Data in '${col.name}' ---`);
            const sample = await mongoose.connection.db.collection(col.name).findOne({});
            console.log(JSON.stringify(sample, null, 2));

            const count = await mongoose.connection.db.collection(col.name).countDocuments();
            console.log(`Total documents: ${count}`);
        }

    } catch (e) {
        console.error("Error:", e);
    } finally {
        await mongoose.disconnect();
    }
}

check();
